`timescale 1ns/1ns

package defs_pkg;

    // =================================================================
    // 1. MEMORY MAP / ADDRESSES
    // =================================================================
    // [NOTE] All addresses below are duplicated in 'regs_pkg.sv'.
    // They are commented out to prevent "double source of truth".
    // Please use regs_pkg::BASE_ADDR_* and regs_pkg::OFFS_* instead.
    
    /* --- MOVED TO regs_pkg ---
    
    // HIGH ADDR (Block Select) -> Use regs_pkg::base_addr_t
    localparam ADDR_A2_PWM  = 8'h00;
    localparam ADDR_A2_LED  = 8'h01;
    localparam ADDR_A2_SYS  = 8'h02;
    localparam ADDR_A2_UART = 8'h03;
    localparam ADDR_A2_MSG  = 8'h04;
    localparam ADDR_A2_IMG  = 8'h05;
    localparam ADDR_A2_FIFO = 8'h06;

    // LOW ADDR (Register Select) -> Use regs_pkg::OFFS_*
    localparam ADDR_A1A0_PWM_CFG        = 16'h0000;
    localparam ADDR_A1A0_PWM_RED_CTRL   = 16'h0004;
    localparam ADDR_A1A0_PWM_GREEN_CTRL = 16'h0008;
    localparam ADDR_A1A0_PWM_BLUE_CTRL  = 16'h000C;
    localparam ADDR_A1A0_LED_CTRL       = 16'h0000;
    localparam ADDR_A1A0_LED_PT_CFG     = 16'h0004;
    localparam ADDR_A1A0_SYS_CTRL       = 16'h0000;
    
    localparam ADDR_A1A0_URAT_TX_CNT    = 16'h0000;
    localparam ADDR_A1A0_UART_RX_CNT    = 16'h0004;

    localparam ADDR_A1A0_MSG_COLOR_CNT  = 16'h0000;
    localparam ADDR_A1A0_MSG_CFG_CNT    = 16'h0004;

    // FULL 24-BIT ADDRESSES
    // (Deprecated: Construct address using {BASE_ADDR_*, OFFS_*})
    localparam ADDR_PWM_CFG        = 24'h000000;
    localparam ADDR_PWM_RED_CTRL   = 24'h000004;
    localparam ADDR_PWM_GREEN_CTRL = 24'h000008;
    localparam ADDR_PWM_BLUE_CTRL  = 24'h00000C;
    
    localparam ADDR_LED_CTRL       = 24'h010000;
    localparam ADDR_LED_PT_CFG     = 24'h010004;

    localparam ADDR_SYS_CTRL       = 24'h020000;
    localparam ADDR_URAT_TX_CNT    = 24'h030000;
    localparam ADDR_UART_RX_CNT    = 24'h030004;

    localparam ADDR_MSG_COLOR_CNT  = 24'h040000;
    localparam ADDR_MSG_CFG_CNT    = 24'h040004;
    
    ---------------------------- */

    // =================================================================
    // 2. GENERAL SYSTEM CONSTANTS
    // =================================================================
    // These are NOT in regs_pkg and should stay here.
    
    localparam DATA_WIDTH     = 13;      
    localparam DEBOUNCE_CYCLE = 5_000_000; // 1sec at 100MHz (Used for Buttons)

    // =================================================================
    // 3. PWM & GAMMA CONFIGURATION
    // =================================================================
    // These are unique to defs_pkg and not found elsewhere.
    
    localparam PWM_MAX = 8192; // Match 10-bit gamma (0-1023)
    localparam PWM_LEN = 9;    // 12-bit PWM output (0-4095)
    localparam GAMMA_OUTPUT = 10;

    // Inlined gamma_table
    localparam logic [9:0] gamma_table [0:255] = '{
        10'd0, 10'd0, 10'd1, 10'd1, 10'd1, 10'd2, 10'd2, 10'd2, 10'd2, 10'd3, 10'd3,
        10'd3, 10'd4, 10'd4, 10'd4, 10'd5, 10'd5, 10'd6, 10'd6, 10'd7, 10'd7, 10'd8,
        10'd8, 10'd9, 10'd9, 10'd10, 10'd11, 10'd11, 10'd12, 10'd13, 10'd13, 10'd14,
        10'd15, 10'd16, 10'd16, 10'd17, 10'd18, 10'd19, 10'd20, 10'd21, 10'd22, 10'd23,
        10'd24, 10'd25, 10'd26, 10'd27, 10'd28, 10'd29, 10'd30, 10'd31, 10'd33, 10'd34,
        10'd35, 10'd36, 10'd38, 10'd39, 10'd40, 10'd42, 10'd43, 10'd45, 10'd46, 10'd48,
        10'd49, 10'd51, 10'd52, 10'd54, 10'd56, 10'd57, 10'd59, 10'd61, 10'd63, 10'd64,
        10'd66, 10'd68, 10'd70, 10'd72, 10'd74, 10'd76, 10'd78, 10'd80, 10'd82, 10'd84,
        10'd86, 10'd88, 10'd91, 10'd93, 10'd95, 10'd97, 10'd100, 10'd102, 10'd105,
        10'd107, 10'd109, 10'd112, 10'd115, 10'd117, 10'd120, 10'd122, 10'd125, 10'd128,
        10'd130, 10'd133, 10'd136, 10'd139, 10'd142, 10'd145, 10'd147, 10'd150, 10'd153,
        10'd156, 10'd160, 10'd163, 10'd166, 10'd169, 10'd172, 10'd175, 10'd179, 10'd182,
        10'd185, 10'd189, 10'd192, 10'd196, 10'd199, 10'd203, 10'd206, 10'd210, 10'd213,
        10'd217, 10'd221, 10'd225, 10'd228, 10'd232, 10'd236, 10'd240, 10'd244, 10'd248,
        10'd252, 10'd256, 10'd260, 10'd264, 10'd268, 10'd272, 10'd277, 10'd281, 10'd285,
        10'd290, 10'd294, 10'd298, 10'd303, 10'd307, 10'd312, 10'd317, 10'd321, 10'd326,
        10'd331, 10'd335, 10'd340, 10'd345, 10'd350, 10'd355, 10'd360, 10'd365, 10'd370,
        10'd375, 10'd380, 10'd385, 10'd390, 10'd395, 10'd401, 10'd406, 10'd411, 10'd417,
        10'd422, 10'd427, 10'd433, 10'd439, 10'd444, 10'd450, 10'd455, 10'd461, 10'd467,
        10'd473, 10'd479, 10'd484, 10'd490, 10'd496, 10'd502, 10'd508, 10'd514, 10'd521,
        10'd527, 10'd533, 10'd539, 10'd546, 10'd552, 10'd558, 10'd565, 10'd571, 10'd578,
        10'd584, 10'd591, 10'd598, 10'd604, 10'd611, 10'd618, 10'd625, 10'd631, 10'd638,
        10'd645, 10'd652, 10'd659, 10'd666, 10'd674, 10'd681, 10'd688, 10'd695, 10'd702,
        10'd710, 10'd717, 10'd725, 10'd732, 10'd740, 10'd747, 10'd755, 10'd763, 10'd770,
        10'd778, 10'd786, 10'd794, 10'd802, 10'd809, 10'd817, 10'd826, 10'd834, 10'd842,
        10'd850, 10'd858, 10'd866, 10'd875, 10'd883, 10'd891, 10'd900, 10'd908, 10'd917,
        10'd925, 10'd934, 10'd943, 10'd952, 10'd960, 10'd969, 10'd978, 10'd987, 10'd996,
        10'd1005, 10'd1014, 10'd1023
    };

endpackage